<?php

require "Hewan.php";

use App\Models\Hewan;

$kucing = new Hewan();
$kucing->nama = "Kucing Persia";

echo $kucing->nama;
