<?php
namespace App\Models;

class Hewan {
    public $nama;
    protected $jenis;
    private $id;

    public function setJenis($jenis) {
        $this->jenis = $jenis;
    }
}
