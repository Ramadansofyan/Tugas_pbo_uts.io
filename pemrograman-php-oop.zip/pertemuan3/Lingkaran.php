<?php

class Lingkaran {
    public const PHI = 3.14;
    public $jari;

    public function __construct($jari = 1) {
        $this->jari = $jari;
    }

    public function hitungLuas() {
        return self::PHI * $this->jari * $this->jari;
    }
}

$lingkaran = new Lingkaran(10);
echo "Luas: " . $lingkaran->hitungLuas();
