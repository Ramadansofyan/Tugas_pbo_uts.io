<?php

class Mahasiswa {
    public function __construct() {
        echo "Object Mahasiswa dibuat.<br>";
    }

    public function __destruct() {
        echo "Object Mahasiswa dihancurkan.<br>";
    }
}

$mhs = new Mahasiswa();
