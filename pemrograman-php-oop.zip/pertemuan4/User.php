<?php

class User {
    public $nama;

    public function setNama($nama) {
        $this->nama = $nama;
    }

    public static function salam() {
        return "Selamat datang di OOP PHP!";
    }
}

$user = new User();
$user->setNama("Budi");

echo User::salam() . "<br>";
echo "Nama user: " . $user->nama;
